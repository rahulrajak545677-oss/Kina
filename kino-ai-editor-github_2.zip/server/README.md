# KINO AI server
Keeps your API key off the phone. Node 18+, no dependencies.

Pick ONE provider with environment variables:
- **Gemini free tier:** `GEMINI_API_KEY=...` (key from aistudio.google.com, no billing needed). Optional `GEMINI_MODEL` (default `gemini-flash-latest`).
- **Any OpenAI-style API (Groq, OpenRouter, ...):** `LLM_BASE_URL=... LLM_API_KEY=... LLM_MODEL=...`
- **Anthropic (paid):** `ANTHROPIC_API_KEY=...`, optional `KINO_MODEL`.

Run: `GEMINI_API_KEY=... node server.js`. Host it with HTTPS (Render, Railway, Fly), then in KINO: Settings > AI server > `https://your-host`.
Request: `{prompt, notes, style, duration, beats, opts, intensity, current, instruction, fxTypes}`. Response: `{summary, events:[...]}`.
