package app.kino.render;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import org.json.JSONArray;
import org.json.JSONObject;

/** Draws the active title (text, animation, style) like textFx() in www/app.js. Premultiplied ARGB bitmap; null when no title shows. */
final class KinoTitle {
  private Bitmap bmp;
  private Canvas cv;

  private static double j(double t, double k) { return Math.sin(t * k) * Math.cos(t * k * 0.37); }

  Bitmap draw(JSONArray events, double t, int w, int h) {
    JSONObject e = null;
    for (int i = 0; i < events.length(); i++) {
      JSONObject x = events.optJSONObject(i);
      if (x == null || !"text".equals(x.optString("track"))) continue;
      double xs = x.optDouble("t"), xd = x.optDouble("d", 1);
      if (t >= xs && t < xs + xd) { e = x; break; }
    }
    if (e == null) return null;
    double s = e.optDouble("t"), d = e.optDouble("d", 1), p = (t - s) / d;
    String label = e.optString("label", "");
    String anim = e.optString("anim", "pop"), style = e.optString("tstyle", "serif");
    double i4 = Math.min(1, p * 4), o = Math.min(1, Math.min(p * 6, (1 - p) * 6)), b = KinoEase.ease("back", i4);
    float k = h / 340f;
    double op = o, dx = 0, dy = 0, rot = 0, sc = 1, skew = 0;
    boolean glitch = false;
    switch (anim) {
      case "fade": op = Math.min(1, Math.min(p * 3, (1 - p) * 3)); break;
      case "rise": dy = (1 - KinoEase.ease("out", i4)) * 50 * k; break;
      case "type":
        op = 1;
        label = label.substring(0, (int) Math.min(label.length(), Math.ceil(label.length() * Math.min(1, p * 2.2))));
        break;
      case "bounce": dy = -Math.abs(Math.sin(p * 14)) * (1 - p) * 40 * k; break;
      case "glitch": dx = j(t, 130) * 8 * k; skew = j(t, 90) * 8; glitch = true; break;
      case "spin": rot = (1 - b) * -180; sc = b; break;
      case "slide": dx = (1 - KinoEase.ease("out", i4)) * -1.2 * w; break;
      default: sc = 0.5 + 0.5 * b;
    }
    if (op <= 0.001 || label.isEmpty()) return null;

    if (bmp == null || bmp.getWidth() != w || bmp.getHeight() != h) {
      bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
      cv = new Canvas(bmp);
    }
    bmp.eraseColor(Color.TRANSPARENT);
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    paint.setTextAlign(Paint.Align.CENTER);
    float size = h * 0.045f;
    int color = Color.WHITE;
    switch (style) {
      case "bold":
        paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        paint.setLetterSpacing(0.04f);
        break;
      case "mono":
        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        paint.setLetterSpacing(0.08f);
        size *= 0.8f;
        color = 0xFF6DFFB0;
        break;
      case "neon":
        paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        size *= 1.05f;
        paint.setShadowLayer(size * 0.5f, 0, 0, 0xFFFF4FD8);
        break;
      default:
        paint.setTypeface(Typeface.create(Typeface.SERIF, Typeface.ITALIC));
        paint.setShadowLayer(h * 0.02f, 0, 0, 0xCCE9CF93);
    }
    paint.setTextSize(size);
    float maxW = w * 0.9f, mw = paint.measureText(label);
    if (mw > maxW) { size *= maxW / mw; paint.setTextSize(size); }
    int alpha = (int) Math.round(255 * Math.min(1, op));
    paint.setColor(color);
    paint.setAlpha(alpha);

    float cx = w / 2f, base = h * 0.84f, py = base - size * 0.35f;
    cv.save();
    cv.translate((float) dx, (float) dy);
    cv.translate(cx, py);
    cv.rotate((float) rot);
    cv.scale((float) sc, (float) sc);
    if (skew != 0) cv.skew((float) Math.tan(Math.toRadians(skew)), 0f);
    cv.translate(-cx, -py);
    if (glitch) {
      paint.setShadowLayer(0, 0, 0, 0);
      paint.setColor(0xFFFF2D55); paint.setAlpha(alpha);
      cv.drawText(label, cx + 3 * k, base, paint);
      paint.setColor(0xFF00E5FF); paint.setAlpha(alpha);
      cv.drawText(label, cx - 3 * k, base, paint);
      paint.setColor(color); paint.setAlpha(alpha);
    }
    cv.drawText(label, cx, base, paint);
    if ("neon".equals(style)) cv.drawText(label, cx, base, paint);
    cv.restore();
    return bmp;
  }
}
