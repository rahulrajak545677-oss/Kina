package app.kino.render;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import org.json.JSONArray;
import org.json.JSONObject;

/** Draws the active reveal / free-draw mask (white = keep the video), like clipTo() in the web export. */
final class KinoMask {
  private final JSONArray events;
  private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
  private Bitmap bmp;
  private Canvas cv;

  KinoMask(JSONArray events) {
    this.events = events;
    fill.setColor(Color.WHITE);
  }

  private static boolean isMask(String t) {
    return "mask".equals(t) || "rcircle".equals(t) || "rwipe".equals(t) || "rsplit".equals(t) || "rrect".equals(t) || "rline".equals(t);
  }

  /** Black/white bitmap for time t, or null when no mask is active. The last active mask wins, as in the web app. */
  Bitmap draw(double t, int w, int h) {
    JSONObject act = null;
    for (int i = 0; i < events.length(); i++) {
      JSONObject e = events.optJSONObject(i);
      if (e == null || !"fx".equals(e.optString("track")) || !isMask(e.optString("type"))) continue;
      double es = e.optDouble("t"), ed = e.optDouble("d", 1);
      if (t >= es && t < es + ed) act = e;
    }
    if (act == null) return null;
    float sc = Math.min(1f, 540f / Math.max(w, h));
    int bw = Math.max(2, Math.round(w * sc)), bh = Math.max(2, Math.round(h * sc));
    if (bmp == null || bmp.getWidth() != bw || bmp.getHeight() != bh) {
      bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
      cv = new Canvas(bmp);
    }
    cv.drawColor(Color.BLACK);
    String type = act.optString("type");
    double s = act.optDouble("t"), d = act.optDouble("d", 1), p = (t - s) / d;
    double shape = "mask".equals(type) ? Math.min(1, Math.min(p * 8, (1 - p) * 8)) : p;
    double v = KinoEase.ease(act.optString("ease", "inout"), shape) * (act.has("amt") ? act.optDouble("amt") : 70) / 100.0;
    double u = Math.min(1, v / 0.7);
    float k = bh / 340f;
    switch (type) {
      case "rcircle":
        cv.drawCircle(bw / 2f, bh / 2f, (float) (u * 0.75 * Math.hypot(bw, bh) / Math.sqrt(2)), fill);
        break;
      case "rwipe":
        cv.drawRect(0, 0, (float) (bw * u), bh, fill);
        break;
      case "rsplit": {
        float m = (float) (bw * 0.5 * (1 - u));
        cv.drawRect(m, 0, bw - m, bh, fill);
        break;
      }
      case "rrect": {
        float mx = (float) (bw * 0.35 * (1 - u)), my = (float) (bh * 0.35 * (1 - u)), r = (float) (20 * (1 - u)) * k;
        cv.drawRoundRect(new RectF(mx, my, bw - mx, bh - my), r, r, fill);
        break;
      }
      case "rline": {
        float my = (float) (bh * 0.49 * (1 - u));
        cv.drawRect(0, my, bw, bh - my, fill);
        break;
      }
      default:
        polygon(act, p, bw, bh);
    }
    return bmp;
  }

  private void polygon(JSONObject e, double p, int bw, int bh) {
    JSONArray pts = e.optJSONArray("pts");
    if (pts == null || pts.length() < 3) { cv.drawColor(Color.WHITE); return; }
    double[] off = track(e.optJSONArray("trk"), p);
    Path path = new Path();
    for (int i = 0; i < pts.length(); i++) {
      JSONArray q = pts.optJSONArray(i);
      if (q == null) continue;
      float x = (float) ((q.optDouble(0) + off[0]) * bw), y = (float) ((q.optDouble(1) + off[1]) * bh);
      if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
    }
    path.close();
    cv.drawPath(path, fill);
  }

  /** Same as tk() in www/app.js: tracking offsets [p, dx, dy] interpolated at p. */
  private static double[] track(JSONArray tr, double p) {
    if (tr == null || tr.length() == 0) return new double[] {0, 0};
    JSONArray a = tr.optJSONArray(0), b = tr.optJSONArray(tr.length() - 1);
    if (a == null || b == null) return new double[] {0, 0};
    for (int i = 0; i < tr.length() - 1; i++) {
      JSONArray c0 = tr.optJSONArray(i), c1 = tr.optJSONArray(i + 1);
      if (c0 != null && c1 != null && p >= c0.optDouble(0) && p <= c1.optDouble(0)) { a = c0; b = c1; break; }
    }
    double u = b.optDouble(0) > a.optDouble(0) ? (p - a.optDouble(0)) / (b.optDouble(0) - a.optDouble(0)) : 0;
    return new double[] {a.optDouble(1) + (b.optDouble(1) - a.optDouble(1)) * u, a.optDouble(2) + (b.optDouble(2) - a.optDouble(2)) * u};
  }
}
