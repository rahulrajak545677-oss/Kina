package app.kino.render;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Freeze frame, Speed ramp and Speed up: same time maths as lost() and srcT() in www/app.js, plus a segment plan for the export. */
final class KinoRemap {
  /** One stretch of the timeline: timeline [t0,t1] shows source [s0,s1]. A freeze holds the frame at s0. */
  static final class Seg {
    double t0, t1, s0, s1;
    boolean freeze;
    double rate() { return t1 > t0 ? (s1 - s0) / (t1 - t0) : 1; }
  }

  private final List<JSONObject> remaps = new ArrayList<>();

  KinoRemap(JSONArray events) {
    for (int i = 0; i < events.length(); i++) {
      JSONObject e = events.optJSONObject(i);
      if (e == null || !"fx".equals(e.optString("track"))) continue;
      String t = e.optString("type");
      if ("freeze".equals(t) || "speed".equals(t) || "fast".equals(t)) remaps.add(e);
    }
  }

  boolean active() { return !remaps.isEmpty(); }

  private static double lost(JSONObject e, double t) {
    double s = e.optDouble("t"), d = e.optDouble("d", 1);
    double p = Math.min(1, Math.max(0, (t - s) / d));
    double amt = (e.has("amt") ? e.optDouble("amt") : 70) / 100.0;
    switch (e.optString("type")) {
      case "freeze": return p * d;
      case "fast": return -amt * 2 * d / Math.PI * (1 - Math.cos(Math.PI * p));
      case "speed": return amt * 0.85 * d / Math.PI * (1 - Math.cos(Math.PI * p));
      default: return 0;
    }
  }

  /** Timeline time to source time. */
  double srcT(double t) {
    double s = t;
    for (JSONObject e : remaps) if (t > e.optDouble("t")) s -= lost(e, t);
    return Math.max(0, s);
  }

  /** Splits [0, end of the source] into freeze and constant-speed pieces (ramps become 0.1 s steps, similar neighbours merge). */
  List<Seg> plan(double srcDur) {
    double end = 0;
    double cap = srcDur * 4 + 120;
    while (end < cap && srcT(end) < srcDur - 0.03) end += 0.02;
    List<Seg> out = new ArrayList<>();
    final double step = 0.1;
    for (double t = 0; t < end - 1e-6; t += step) {
      double t1 = Math.min(end, t + step);
      Seg s = new Seg();
      s.t0 = t; s.t1 = t1; s.s0 = srcT(t); s.s1 = Math.min(srcDur, srcT(t1));
      s.freeze = (s.s1 - s.s0) < 1e-4 * (t1 - t);
      if (!s.freeze && Math.abs(s.rate() - 1) < 0.02) { s.s1 = s.s0 + (t1 - t); }   // treat as normal speed
      Seg last = out.isEmpty() ? null : out.get(out.size() - 1);
      if (last != null && last.freeze == s.freeze && (s.freeze || Math.abs(last.rate() - s.rate()) < 0.03)) {
        last.t1 = s.t1; last.s1 = s.s1;
      } else {
        out.add(s);
      }
    }
    return out;
  }
}
