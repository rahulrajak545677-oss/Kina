package app.kino.render;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.SonicAudioProcessor;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.Presentation;
import androidx.media3.effect.SpeedChangeEffect;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.common.collect.ImmutableList;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

/**
 * Native render (written, not compiled against real Media3). Motion and camera effects, colour, blur, distortion,
 * kaleidoscope, cube, echo, masks, second layer with blend modes, titles, and freeze / speed remaps in one export, H.264 out.
 */
@UnstableApi
@CapacitorPlugin(name = "KinoRender")
public class KinoRenderPlugin extends Plugin {
  private static boolean has(JSArray events, String type) {
    for (int i = 0; i < events.length(); i++) {
      JSONObject e = events.optJSONObject(i);
      if (e != null && "fx".equals(e.optString("track")) && type.equals(e.optString("type"))) return true;
    }
    return false;
  }

  @PluginMethod
  public void render(PluginCall call) {
    final String src = call.getString("src");
    final String out = call.getString("out");
    final JSArray events = call.getArray("events");
    final int height = call.getInt("height", 1080);
    final int fps = call.getInt("fps", 30);
    final String layer2Uri = call.getString("layer2Src");
    final int blend = call.getInt("blend", 0);
    Double opD = call.getDouble("opacity", 0.8);
    final float opacity = opD == null ? 0.8f : opD.floatValue();
    if (src == null || out == null || events == null) { call.reject("src, out and events are required"); return; }

    final Context ctx = getContext();
    // Frame grabbing (freeze frames, durations) is slow, so prepare off the UI thread, then start Transformer on it.
    new Thread(() -> {
      final List<File> temp = new ArrayList<>();
      final KinoLayer srcLayer = new KinoLayer(ctx, src);
      final KinoLayer layer2 = (layer2Uri != null && !layer2Uri.isEmpty()) ? new KinoLayer(ctx, layer2Uri) : null;
      final Runnable cleanup = () -> {
        srcLayer.close();
        if (layer2 != null) layer2.close();
        for (File f : temp) //noinspection ResultOfMethodCallIgnored
          f.delete();
      };
      try {
        final KinoRemap remap = new KinoRemap(events);
        final KinoMask mask = new KinoMask(events);
        final KinoLayer echoLayer = has(events, "echo") ? srcLayer : null;
        final List<EditedMediaItem> items = new ArrayList<>();

        if (!remap.active()) {
          items.add(edited(MediaItem.fromUri(Uri.parse(src)), KinoClock.absolute(), 1f, false, 0, fps, height,
              events, remap, mask, layer2, echoLayer, blend, opacity));
        } else {
          if (!srcLayer.ok() || srcLayer.duration() <= 0) throw new IllegalStateException("Could not read the video length");
          List<KinoRemap.Seg> plan = remap.plan(srcLayer.duration());
          if (plan.size() > 300) throw new IllegalStateException("Too many speed segments");
          int n = 0;
          for (KinoRemap.Seg s : plan) {
            KinoClock clock = KinoClock.segment(s.t0);
            if (s.freeze) {
              Bitmap b = srcLayer.fullFrame(s.s0);
              if (b == null) throw new IllegalStateException("Could not grab the freeze frame");
              File f = new File(ctx.getCacheDir(), "kino-freeze-" + (n++) + ".png");
              try (FileOutputStream os = new FileOutputStream(f)) { b.compress(Bitmap.CompressFormat.PNG, 100, os); }
              temp.add(f);
              long us = Math.max(1000L, Math.round((s.t1 - s.t0) * 1e6));
              items.add(edited(new MediaItem.Builder().setUri(Uri.fromFile(f)).build(), clock, 1f, true, us, fps, height,
                  events, remap, mask, layer2, echoLayer, blend, opacity));
            } else {
              MediaItem mi = new MediaItem.Builder().setUri(Uri.parse(src))
                  .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                      .setStartPositionMs(Math.round(s.s0 * 1000)).setEndPositionMs(Math.round(s.s1 * 1000)).build())
                  .build();
              float rate = (float) s.rate();
              items.add(edited(mi, clock, Math.abs(rate - 1f) < 0.02f ? 1f : rate, false, 0, fps, height,
                  events, remap, mask, layer2, echoLayer, blend, opacity));
            }
          }
        }

        final boolean remapped = remap.active();
        getActivity().runOnUiThread(() -> {
          try {
            Composition comp = new Composition.Builder(new EditedMediaItemSequence(ImmutableList.copyOf(items)))
                .experimentalSetForceAudioTrack(remapped)   // freeze segments have no audio, so ask for silence there
                .build();
            Transformer tf = new Transformer.Builder(ctx)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(new Transformer.Listener() {
                  @Override public void onCompleted(Composition c, ExportResult r) {
                    cleanup.run(); JSObject o = new JSObject(); o.put("path", out); call.resolve(o);
                  }
                  @Override public void onError(Composition c, ExportResult r, ExportException e) {
                    cleanup.run(); call.reject(String.valueOf(e.getMessage()));
                  }
                }).build();
            tf.start(comp, out);
          } catch (Exception e) { cleanup.run(); call.reject(String.valueOf(e.getMessage())); }
        });
      } catch (Exception e) {
        cleanup.run();
        call.reject(String.valueOf(e.getMessage()));
      }
    }, "kino-render-prep").start();
  }

  /** One item of the export: optional speed change, camera/motion matrix, the KINO shader, then the output size. */
  private static EditedMediaItem edited(MediaItem mi, KinoClock clock, float speed, boolean image, long imageDurUs, int fps, int height,
      JSArray events, KinoRemap remap, KinoMask mask, KinoLayer layer2, KinoLayer echoLayer, int blend, float opacity) {
    ImmutableList.Builder<Effect> v = ImmutableList.builder();
    if (speed != 1f) v.add(new SpeedChangeEffect(speed));
    v.add(new KinoMotion(events, clock));
    // The shader needs a GL context, so it is created by Media3 on its GL thread, not here.
    GlEffect kino = (c, useHdr) -> new KinoShader(c, events, clock, remap, mask, layer2, echoLayer, blend, opacity);
    v.add(kino);
    v.add(Presentation.createForHeight(height));
    ImmutableList<AudioProcessor> audio = ImmutableList.of();
    if (speed != 1f) {
      SonicAudioProcessor sonic = new SonicAudioProcessor();
      sonic.setSpeed(speed);
      sonic.setPitch(1f);
      audio = ImmutableList.of(sonic);
    }
    EditedMediaItem.Builder b = new EditedMediaItem.Builder(mi).setEffects(new Effects(audio, v.build()));
    if (image) b.setDurationUs(imageDurUs).setFrameRate(fps);
    return b.build();
  }
}
