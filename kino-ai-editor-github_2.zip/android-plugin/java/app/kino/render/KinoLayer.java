package app.kino.render;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;

/** Pulls single frames out of a video with MediaMetadataRetriever (second layer, echo). Slow but simple. */
final class KinoLayer {
  private MediaMetadataRetriever mmr;
  private double durS;
  private int lw, lh;
  private Bitmap bmp;
  private double bmpT = -1;
  private int version;

  KinoLayer(Context ctx, String uri) {
    if (uri == null || uri.isEmpty()) return;
    try {
      MediaMetadataRetriever r = new MediaMetadataRetriever();
      r.setDataSource(ctx, Uri.parse(uri));
      durS = num(r, MediaMetadataRetriever.METADATA_KEY_DURATION) / 1000.0;
      int vw = num(r, MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH), vh = num(r, MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
      int rot = num(r, MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
      if (rot == 90 || rot == 270) { int tmp = vw; vw = vh; vh = tmp; }
      if (vw > 0 && vh > 0) {
        float f = Math.min(1f, 720f / Math.max(vw, vh));
        lw = Math.round(vw * f);
        lh = Math.round(vh * f);
      }
      mmr = r;
    } catch (RuntimeException e) {
      mmr = null;
    }
  }

  private static int num(MediaMetadataRetriever r, int key) {
    try {
      String v = r.extractMetadata(key);
      return v == null ? 0 : Integer.parseInt(v);
    } catch (NumberFormatException e) {
      return 0;
    }
  }

  boolean ok() { return mmr != null; }

  double duration() { return durS; }

  /** Frame at source time t (clamped to the clip). Returns the latest bitmap, or null if none could be decoded. */
  Bitmap frame(double t) {
    if (mmr == null) return null;
    double tl = Math.max(0, Math.min(t, (durS > 0 ? durS : t) - 0.05));
    if (bmp == null || Math.abs(tl - bmpT) > 1e-3) {
      Bitmap b;
      try {
        long us = (long) (tl * 1e6);
        if (Build.VERSION.SDK_INT >= 27 && lw > 0) b = mmr.getScaledFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST, lw, lh);
        else b = mmr.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST);
      } catch (RuntimeException e) {
        b = null;
      }
      if (b != null) { bmp = b; bmpT = tl; version++; }
    }
    return bmp;
  }

  /** Full-size frame at source time t, for freeze frames. */
  Bitmap fullFrame(double t) {
    if (mmr == null) return null;
    try {
      double tl = Math.max(0, Math.min(t, (durS > 0 ? durS : t) - 0.05));
      return mmr.getFrameAtTime((long) (tl * 1e6), MediaMetadataRetriever.OPTION_CLOSEST);
    } catch (RuntimeException e) {
      return null;
    }
  }

  /** Bumps whenever frame() decoded a new bitmap, so callers know when to re-upload. */
  int version() { return version; }

  /** Cover-fit visible fraction of this layer's last frame inside an out-sized frame. */
  float[] coverScale(int outW, int outH) {
    if (bmp == null) return new float[] {1f, 1f};
    float bw = bmp.getWidth(), bh = bmp.getHeight();
    float s = Math.max(outW / bw, outH / bh);
    return new float[] {outW / (bw * s), outH / (bh * s)};
  }

  void close() {
    if (mmr != null) {
      try { mmr.release(); } catch (Exception ignored) { }
      mmr = null;
    }
  }
}
