package com.kino.aieditor;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.OutputStream;

/** Saves a video straight into the phone gallery (Movies/KINO) using MediaStore. */
@CapacitorPlugin(name = "KinoSave")
public class KinoSavePlugin extends Plugin {
  private Uri uri;
  private OutputStream os;

  private void closeQuiet() {
    try { if (os != null) os.close(); } catch (Exception ignored) {}
    os = null;
  }

  @PluginMethod
  public void begin(PluginCall call) {
    try {
      closeQuiet();
      String name = call.getString("name", "kino-edit.mp4");
      String mime = call.getString("mime", "video/mp4");
      ContentResolver cr = getContext().getContentResolver();
      ContentValues v = new ContentValues();
      v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
      v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
      Uri coll;
      if (Build.VERSION.SDK_INT >= 29) {
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/KINO");
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        coll = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
      } else {
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "KINO");
        dir.mkdirs();
        v.put(MediaStore.MediaColumns.DATA, new File(dir, name).getAbsolutePath());
        coll = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
      }
      uri = cr.insert(coll, v);
      if (uri == null) throw new Exception("could not create the gallery entry");
      os = cr.openOutputStream(uri);
      if (os == null) throw new Exception("could not open the gallery file");
      call.resolve();
    } catch (Exception e) {
      call.reject(String.valueOf(e.getMessage()));
    }
  }

  @PluginMethod
  public void append(PluginCall call) {
    try {
      if (os == null) throw new Exception("save was not started");
      os.write(Base64.decode(call.getString("data", ""), Base64.DEFAULT));
      call.resolve();
    } catch (Exception e) {
      call.reject(String.valueOf(e.getMessage()));
    }
  }

  @PluginMethod
  public void finish(PluginCall call) {
    try {
      if (os != null) { os.flush(); os.close(); os = null; }
      if (uri == null) throw new Exception("nothing to finish");
      if (Build.VERSION.SDK_INT >= 29) {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.IS_PENDING, 0);
        getContext().getContentResolver().update(uri, v, null, null);
      }
      JSObject r = new JSObject();
      r.put("uri", uri.toString());
      call.resolve(r);
    } catch (Exception e) {
      call.reject(String.valueOf(e.getMessage()));
    }
  }

  @PluginMethod
  public void abort(PluginCall call) {
    closeQuiet();
    try { if (uri != null) getContext().getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
    uri = null;
    call.resolve();
  }
}
