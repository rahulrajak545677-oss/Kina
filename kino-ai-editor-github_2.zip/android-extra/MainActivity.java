package com.kino.aieditor;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(KinoSavePlugin.class);
    super.onCreate(savedInstanceState);
  }
}
