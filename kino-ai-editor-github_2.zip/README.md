# KINO: AI video editor

Dark, phone-first video editor. Write a prompt and notes, the AI plans the edit (cuts, effects, titles), then you fine-tune it on a timeline and export.

## Quick start
- **Preview in a browser:** open `www/index.html` in Chrome (phone view). Runs offline.
- **Build the APK on GitHub (no Android Studio):** push this whole folder (keep `.github/`). Actions tab > latest run > Artifacts > `kino-debug-apk`.
- **Build locally:** `npm install && npx cap add android && npx cap sync android && npx cap open android`.

## Real AI plan (optional)
`server/` holds a small Node server that asks an AI (free Gemini tier, any OpenAI-style API, or Claude) for the edit plan, so your API key stays off the phone. See `server/README.md`. Host it with HTTPS, then paste the address into **Settings > AI server**. Without it the app uses an offline sample plan.

## What is in the app
- **Screens:** Home, Create, Studio (preview, timeline, AI plan, revise chat, undo/redo, export), Library, Settings. The edit autosaves on the phone.
- **Library:** about 135 effects, presets and recipes, search by name or #tag, and a Guide that lists the full vocabulary. Nearly every Guide item is gold (works). Tap a gold chip to add it at the playhead.
- **Effects:** camera moves, colour grading, blur, glow and light, glitch/VHS, distortion, patterns, edge and sketch looks, keying, blend layers, reveals, free-draw masks with subject tracking, keyframe motion with easing curves (including Bezier), second video layer with blend modes, echo, freeze, speed ramp, speed up, loop, reverse, kaleidoscope, 3D cube.
- **Titles:** 23 animations, 4 styles, keyframes.
- **Beats:** import decodes the audio and finds beats (onset detection with a tempo grid). Beat Sync, Beat Markers and Visual Rhythm use them.
- **Export:** records the stage in real time with MediaRecorder (MP4 when the phone supports it, otherwise WebM) and saves it straight into the gallery (Movies/KINO) with the small `android-extra/KinoSavePlugin.java` plugin. The build workflow copies that plugin into the Android project. If the gallery save fails it falls back to the share sheet.

## Honest limits
- Preview effects are CSS/SVG/canvas approximations. The exported file is the real result.
- Beat detection can miss or misplace beats on some music. Tracking masks can drift on fast or look-alike motion.
- Chroma/Luma key show the dark stage behind the picture. Cylinder and Sphere use an SVG displacement map. Wave and Shake titles move the whole line.
- Not built: Grid Repeat, Reflection, Parallax, Frame Blending, Match Cut (their Guide chips explain why).
- Watermark is saved as a setting but not drawn on exports.
- `android-plugin/` (native Media3/OpenGL export) is written but was never compiled or tested, and it does not know the newest effects. Do not copy it in until you have a working APK. Steps are in `android-plugin/README.md`.
- Nothing in this project has been tested on a real phone yet. Please try it and report what breaks.

## Fixes from device testing
Playback stutter fixed: preview cards no longer run while the Studio plays, style writes are cached, the timeline no longer scrolls every frame, and the video now speeds up or slows down slightly to catch up instead of seeking. Export now saves to the gallery instead of opening the share sheet. Not yet verified on a phone after these changes.

## Project layout
`www/` app (index.html, app.js, styles.css) · `server/` AI plan server · `android-plugin/` experimental native export · `.github/workflows/build-apk.yml` APK build.

## Plan JSON shape
`{track:'video|fx|text|audio', type, label, t, d, amt, ease, anim, tstyle, kf:[{p,x,y,s,r,e}]}`. `p` is 0..1 along the clip, `x`/`y` are % of the frame, `s` is scale %, `r` is degrees, `e` is the ease into that key.
